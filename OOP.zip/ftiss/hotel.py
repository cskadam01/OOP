#Szálloda és annak szobái 
class Hotel:
    def __init__(self, hotelName, hotelLocation,):
        self.hotelName=hotelName
        self.hotelLocation=hotelLocation 
        
class Room:
    def __init__(self, price, roomNum,):
        self.price=price
        self.roomNum=roomNum


class OneBedRoom(Room):
    def __init__(self, roomNum):
        super().__init__(price=8000, roomNum=roomNum,)

class TwoBedRoom:
    def __init__(self,roomNum ):        
        super().__init__(price=15000, roomNum=roomNum,)

